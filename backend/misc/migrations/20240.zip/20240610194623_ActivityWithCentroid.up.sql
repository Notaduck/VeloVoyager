ALTER TABLE activities
ADD COLUMN centroid Point NOT NULL DEFAULT '(0,0)'