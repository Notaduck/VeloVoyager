-- Remove the centroid column
ALTER TABLE activities
DROP COLUMN IF EXISTS centroid;
